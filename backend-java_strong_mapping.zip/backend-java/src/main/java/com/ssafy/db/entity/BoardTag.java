package com.ssafy.db.entity;

public enum BoardTag {
    QNA, EXAM, JOB, FREE, NOTICE, SCHEDULE
}
