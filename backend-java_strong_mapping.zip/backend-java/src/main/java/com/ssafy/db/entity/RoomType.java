package com.ssafy.db.entity;

public enum RoomType {
    STUDY, PROJECT, BOARD
}
