package com.ssafy.db.entity;

public enum ClubTag {
    STUDY, PROJECT;
}
