package com.ssafy.db.entity;

public enum UserClass {
    JAVA, PYTHON, EMBEDDED, MOBILE
}
