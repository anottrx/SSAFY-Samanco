package com.ssafy.db.entity;

public enum UserJoinClubStatus {
    BEFORE, OK, NO, CANCEL
}
