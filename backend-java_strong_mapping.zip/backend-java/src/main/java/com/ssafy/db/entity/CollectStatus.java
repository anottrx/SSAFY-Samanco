package com.ssafy.db.entity;

public enum CollectStatus {
    ING, END
}
