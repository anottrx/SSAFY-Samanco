package com.ssafy.db.entity;

public enum UserPosition {
    FRONTEND, BACKEND,  MOBILE, EMBEDDED
}
